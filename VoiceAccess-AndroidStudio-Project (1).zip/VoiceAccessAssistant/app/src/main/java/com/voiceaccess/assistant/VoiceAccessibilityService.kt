package com.voiceaccess.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/**
 * VoiceAccessibilityService
 *
 * यह सर्विस डिवाइस की स्क्रीन को पढ़ने (Screen Reading),
 * टेक्स्ट या को-ऑर्डिनेट्स पर टैप करने (Simulate Tap/Click),
 * स्क्रॉल करने और ग्लोबल नेविगेशन (Back, Home, Recents) को हैंडल करती है।
 */
class VoiceAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "VoiceAccessibility"
        
        // सर्विस का स्टेटिक इंस्टेंस ताकि VoiceManager और FloatingOverlay इसे सीधे कॉल कर सकें
        @Volatile
        var instance: VoiceAccessibilityService? = null
            private set

        val isServiceRunning: Boolean
            get() = instance != null
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "VoiceAccessibilityService connected successfully!")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // स्क्रीन में किसी भी बदलाव पर इवेंट मिलता है
        if (event == null) return
        val packageName = event.packageName?.toString() ?: ""
        val eventType = event.eventType
        // आवश्यकतानुसार इवेंट लॉगिंग या ऑटो-प्रोसेसिंग की जा सकती है
    }

    override fun onInterrupt() {
        Log.w(TAG, "VoiceAccessibilityService interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) {
            instance = null
        }
        Log.i(TAG, "VoiceAccessibilityService destroyed")
    }

    // ==========================================
    // 1. स्क्रीन पढ़ना (SCREEN READING)
    // ==========================================

    /**
     * वर्तमान स्क्रीन के सभी विजिबल टेक्स्ट, बटन्स और डिस्क्रिप्शन्स को पढ़कर एक स्ट्रिंग में लौटाता है
     */
    fun readScreenContent(): ScreenReadResult {
        val rootNode = rootInActiveWindow ?: return ScreenReadResult(
            packageName = "Unknown",
            appName = "None",
            visibleTexts = emptyList(),
            clickableItems = emptyList(),
            fullSummary = "स्क्रीन पर कोई डेटा नहीं मिला या स्क्रीन लॉक है।"
        )

        val texts = mutableListOf<String>()
        val clickables = mutableListOf<ClickableItem>()
        val packageName = rootNode.packageName?.toString() ?: "Unknown"

        traverseNode(rootNode, texts, clickables)

        val summary = if (texts.isEmpty()) {
            "वर्तमान स्क्रीन खाली है या कोई पठनीय टेक्स्ट नहीं है।"
        } else {
            "स्क्रीन पर विजिबल टेक्स्ट: " + texts.take(15).joinToString(", ")
        }

        return ScreenReadResult(
            packageName = packageName,
            appName = getAppNameFromPackage(packageName),
            visibleTexts = texts,
            clickableItems = clickables,
            fullSummary = summary
        )
    }

    private fun traverseNode(
        node: AccessibilityNodeInfo?,
        texts: MutableList<String>,
        clickables: MutableList<ClickableItem>
    ) {
        if (node == null || !node.isVisibleToUser) return

        val text = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()

        val label = when {
            !text.isNullOrEmpty() -> text
            !desc.isNullOrEmpty() -> desc
            else -> null
        }

        if (!label.isNullOrEmpty()) {
            texts.add(label)
        }

        if (node.isClickable && !label.isNullOrEmpty()) {
            val bounds = Rect()
            node.getBoundsInScreen(bounds)
            clickables.add(
                ClickableItem(
                    label = label,
                    className = node.className?.toString() ?: "",
                    bounds = bounds
                )
            )
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            traverseNode(child, texts, clickables)
        }
    }

    // ==========================================
    // 2. ऑटोमेशन एवं टैप करना (GESTURE & TAP)
    // ==========================================

    /**
     * टेक्स्ट या लेबल के आधार पर स्क्रीन पर मौजूद बटन/व्यू पर क्लिक करता है
     */
    fun clickOnText(targetText: String, ignoreCase: Boolean = true): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        
        // 1. AccessibilityNodeInfo.findAccessibilityNodeInfosByText से सर्च करें
        val nodes = rootNode.findAccessibilityNodeInfosByText(targetText)
        for (node in nodes) {
            if (node.isVisibleToUser) {
                // अगर नोड खुद क्लिकेबल है, तो ACTION_CLICK करें
                if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    Log.i(TAG, "Clicked node via ACTION_CLICK: $targetText")
                    return true
                }
                // अगर पैरेंट क्लिकेबल है
                var parent = node.parent
                while (parent != null) {
                    if (parent.isClickable && parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        Log.i(TAG, "Clicked parent node via ACTION_CLICK: $targetText")
                        return true
                    }
                    parent = parent.parent
                }

                // अगर नोड डायरेक्ट क्लिकेबल नहीं है, तो स्क्रीन को-ऑर्डिनेट्स पर जेस्चर टैप भेजें
                val bounds = Rect()
                node.getBoundsInScreen(bounds)
                if (bounds.width() > 0 && bounds.height() > 0) {
                    return tapCoordinates(bounds.centerX().toFloat(), bounds.centerY().toFloat())
                }
            }
        }

        // 2. फ़ॉलबैक: पूरा ट्री मैन्युअली स्कैन करें (कंटेंट डिस्क्रिप्शन या पार्सल मैच के लिए)
        val matchedNode = findNodeFuzzy(rootNode, targetText.lowercase(Locale.ROOT))
        if (matchedNode != null) {
            val bounds = Rect()
            matchedNode.getBoundsInScreen(bounds)
            return tapCoordinates(bounds.centerX().toFloat(), bounds.centerY().toFloat())
        }

        return false
    }

    private fun findNodeFuzzy(node: AccessibilityNodeInfo?, target: String): AccessibilityNodeInfo? {
        if (node == null || !node.isVisibleToUser) return null

        val text = node.text?.toString()?.lowercase(Locale.ROOT) ?: ""
        val desc = node.contentDescription?.toString()?.lowercase(Locale.ROOT) ?: ""

        if (text.contains(target) || desc.contains(target)) {
            return node
        }

        for (i in 0 until node.childCount) {
            val found = findNodeFuzzy(node.getChild(i), target)
            if (found != null) return found
        }
        return null
    }

    /**
     * स्क्रीन के निश्चित X, Y को-ऑर्डिनेट्स पर टैप (Tap Gesture) करता है
     */
    fun tapCoordinates(x: Float, y: Float, callback: ((Boolean) -> Unit)? = null): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            Log.e(TAG, "Gestures require Android 7.0 (API 24) or higher")
            callback?.invoke(false)
            return false
        }

        val path = Path().apply {
            moveTo(x, y)
            lineTo(x, y)
        }

        val stroke = GestureDescription.StrokeDescription(path, 0, 100)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        return dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                Log.i(TAG, "Tap gesture completed successfully at ($x, $y)")
                callback?.invoke(true)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                Log.w(TAG, "Tap gesture cancelled at ($x, $y)")
                callback?.invoke(false)
            }
        }, null)
    }

    // ==========================================
    // 3. स्क्रॉल करना (SCROLL UP / DOWN)
    // ==========================================

    fun scrollDown(): Boolean {
        val rootNode = rootInActiveWindow
        if (rootNode != null) {
            val scrollable = findScrollableNode(rootNode)
            if (scrollable != null && scrollable.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) {
                return true
            }
        }
        // फ़ॉलबैक: स्क्रीन के बीच में स्वाइप जेस्चर करें (नीचे से ऊपर)
        val displayMetrics = resources.displayMetrics
        val centerX = displayMetrics.widthPixels / 2f
        val startY = displayMetrics.heightPixels * 0.75f
        val endY = displayMetrics.heightPixels * 0.25f
        return swipe(centerX, startY, centerX, endY, 300)
    }

    fun scrollUp(): Boolean {
        val rootNode = rootInActiveWindow
        if (rootNode != null) {
            val scrollable = findScrollableNode(rootNode)
            if (scrollable != null && scrollable.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)) {
                return true
            }
        }
        val displayMetrics = resources.displayMetrics
        val centerX = displayMetrics.widthPixels / 2f
        val startY = displayMetrics.heightPixels * 0.25f
        val endY = displayMetrics.heightPixels * 0.75f
        return swipe(centerX, startY, centerX, endY, 300)
    }

    private fun findScrollableNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null || !node.isVisibleToUser) return null
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val scrollable = findScrollableNode(node.getChild(i))
            if (scrollable != null) return scrollable
        }
        return null
    }

    fun swipe(startX: Float, startY: Float, endX: Float, endY: Float, durationMs: Long = 300): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    // ==========================================
    // 4. ग्लोबल एक्शन्स (BACK, HOME, RECENTS)
    // ==========================================

    fun goBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun goHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun openRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun openNotifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    // ==========================================
    // 5. दूसरे ऐप्स लॉन्च करना (OPEN OTHER APPS)
    // ==========================================

    fun launchAppByName(appNameQuery: String): Boolean {
        val pm = packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val apps = pm.queryIntentActivities(mainIntent, 0)
        val query = appNameQuery.lowercase(Locale.ROOT).trim()

        for (resolveInfo in apps) {
            val label = resolveInfo.loadLabel(pm).toString().lowercase(Locale.ROOT)
            val pkg = resolveInfo.activityInfo.packageName
            if (label.contains(query) || pkg.contains(query)) {
                val launchIntent = pm.getLaunchIntentForPackage(pkg)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(launchIntent)
                    return true
                }
            }
        }
        return false
    }

    private fun getAppNameFromPackage(packageName: String): String {
        return try {
            val pm = packageManager
            val appInfo = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(appInfo).toString()
        } catch (e: Exception) {
            packageName
        }
    }
}

data class ScreenReadResult(
    val packageName: String,
    val appName: String,
    val visibleTexts: List<String>,
    val clickableItems: List<ClickableItem>,
    val fullSummary: String
)

data class ClickableItem(
    val label: String,
    val className: String,
    val bounds: Rect
)
