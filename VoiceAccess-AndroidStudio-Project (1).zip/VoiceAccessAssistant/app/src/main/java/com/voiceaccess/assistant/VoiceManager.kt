package com.voiceaccess.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale

/**
 * VoiceManager
 *
 * यह क्लास स्पीच रिकग्निशन (आवाज़ पहचानना) और टेक्स्ट-टू-स्पीच (आवाज़ में जवाब देना) को
 * प्रबंधित करती है। यह हिंदी (hi-IN) और अंग्रेजी (en-US / en-IN) दोनों भाषाओं के कमांड्स समझती है।
 */
class VoiceManager(
    private val context: Context,
    private val onCommandCallback: ((command: String, result: VoiceExecutionResult) -> Unit)? = null
) : RecognitionListener, TextToSpeech.OnInitListener {

    companion object {
        private const val TAG = "VoiceManager"
    }

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false
    private var isListening = false
    private val mainHandler = Handler(Looper.getMainLooper())

    var currentLanguage: String = "hi-IN" // डिफॉल्ट हिंदी, "en-US" भी सपोर्टेड

    init {
        initSpeechRecognizer()
        initTextToSpeech()
    }

    private fun initSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(this@VoiceManager)
            }
            Log.i(TAG, "SpeechRecognizer initialized")
        } else {
            Log.e(TAG, "Speech recognition is NOT available on this device!")
        }
    }

    private fun initTextToSpeech() {
        textToSpeech = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = textToSpeech?.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // हिंदी न मिलने पर इंग्लिश सेट करें
                textToSpeech?.language = Locale.US
            }
            isTtsReady = true
            Log.i(TAG, "TextToSpeech initialized successfully")
        } else {
            Log.e(TAG, "TextToSpeech initialization failed: $status")
        }
    }

    // ==========================================
    // वॉयस रिकॉर्डिंग शुरू / बंद करना
    // ==========================================

    fun startListening() {
        if (isListening) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, currentLanguage)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, currentLanguage)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "बोलिए (उदा: स्क्रीन पढ़ो, यूट्यूब खोलो, टैप करो)...")
        }

        try {
            speechRecognizer?.startListening(intent)
            isListening = true
        } catch (e: Exception) {
            Log.e(TAG, "Error starting speech recognition: ${e.message}")
        }
    }

    fun stopListening() {
        if (!isListening) return
        try {
            speechRecognizer?.stopListening()
            isListening = false
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping speech recognition: ${e.message}")
        }
    }

    // ==========================================
    // टेक्स्ट टू स्पीच (आवाज़ में बोलना)
    // ==========================================

    fun speak(text: String, onDone: (() -> Unit)? = null) {
        if (!isTtsReady || textToSpeech == null) {
            Log.w(TAG, "TTS is not ready yet")
            return
        }

        val utteranceId = "VoiceManager_${System.currentTimeMillis()}"
        if (onDone != null) {
            textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) {
                    if (id == utteranceId) {
                        mainHandler.post { onDone() }
                    }
                }
                override fun onError(id: String?) {}
            })
        }

        textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    // ==========================================
    // कमांड इंटरप्रेटर (VOICE COMMAND PARSER)
    // ==========================================

    /**
     * बोले गए वाक्य को पहचानकर एक्सेसिबिलिटी सर्विस को सही एक्शन देता है
     */
    fun processVoiceCommand(rawSpokenText: String) {
        val service = VoiceAccessibilityService.instance
        val command = rawSpokenText.trim().lowercase(Locale.ROOT)
        Log.i(TAG, "Processing voice command: '$rawSpokenText'")

        if (service == null) {
            val msg = "एक्सेसिबिलिटी सर्विस चालू नहीं है। कृपया सेटिंग्स में जाकर इसे ऑन करें।"
            speak(msg)
            onCommandCallback?.invoke(rawSpokenText, VoiceExecutionResult(false, msg))
            return
        }

        val result: VoiceExecutionResult = when {
            // 1. स्क्रीन पढ़ो (READ SCREEN)
            command.contains("स्क्रीन पढ़ो") || command.contains("read screen") ||
            command.contains("क्या है स्क्रीन पर") || command.contains("what's on screen") -> {
                val screenInfo = service.readScreenContent()
                speak(screenInfo.fullSummary)
                VoiceExecutionResult(true, "स्क्रीन पढ़ी जा रही है: " + screenInfo.visibleTexts.size + " एलिमेंट्स मिले।")
            }

            // 2. वापस जाओ (GO BACK)
            command.contains("वापस") || command.contains("बैक") || command.contains("back") -> {
                val success = service.goBack()
                val msg = if (success) "वापस जा रहे हैं" else "बैक एक्शन विफल हुआ"
                speak(msg)
                VoiceExecutionResult(success, msg)
            }

            // 3. होम स्क्रीन (GO HOME)
            command.contains("होम") || command.contains("home") -> {
                val success = service.goHome()
                val msg = if (success) "होम स्क्रीन पर गए" else "होम एक्शन विफल"
                speak(msg)
                VoiceExecutionResult(success, msg)
            }

            // 4. हाल के ऐप्स (RECENT APPS)
            command.contains("हाल के ऐप्स") || command.contains("recents") || command.contains("recent apps") -> {
                val success = service.openRecents()
                val msg = if (success) "हाल के ऐप्स खोले गए" else "विफल"
                speak(msg)
                VoiceExecutionResult(success, msg)
            }

            // 5. नीचे स्क्रॉल करो (SCROLL DOWN)
            command.contains("नीचे स्क्रॉल") || command.contains("scroll down") || command.contains("नीचे जाओ") -> {
                val success = service.scrollDown()
                val msg = if (success) "नीचे स्क्रॉल किया" else "स्क्रॉल नहीं हो सका"
                speak(msg)
                VoiceExecutionResult(success, msg)
            }

            // 6. ऊपर स्क्रॉल करो (SCROLL UP)
            command.contains("ऊपर स्क्रॉल") || command.contains("scroll up") || command.contains("ऊपर जाओ") -> {
                val success = service.scrollUp()
                val msg = if (success) "ऊपर स्क्रॉल किया" else "स्क्रॉल नहीं हो सका"
                speak(msg)
                VoiceExecutionResult(success, msg)
            }

            // 7. ऐप खोलो (OPEN APP)
            command.startsWith("खोलो") || command.startsWith("open") || command.contains("ऐप खोलो") -> {
                val appName = command.replace("खोलो", "")
                    .replace("open", "")
                    .replace("app", "")
                    .replace("ऐप", "")
                    .trim()
                val success = service.launchAppByName(appName)
                val msg = if (success) "$appName खोला जा रहा है" else "$appName नहीं मिला"
                speak(msg)
                VoiceExecutionResult(success, msg)
            }

            // 8. टैप / क्लिक करो (CLICK / TAP)
            command.contains("टैप करो") || command.contains("दबाओ") ||
            command.contains("क्लिक करो") || command.contains("click") || command.contains("tap") -> {
                val targetText = command.replace("टैप करो", "")
                    .replace("दबाओ", "")
                    .replace("क्लिक करो", "")
                    .replace("click", "")
                    .replace("tap", "")
                    .replace("on", "")
                    .replace("पर", "")
                    .trim()
                val success = service.clickOnText(targetText)
                val msg = if (success) "$targetText पर टैप किया गया" else "$targetText स्क्रीन पर नहीं मिला"
                speak(msg)
                VoiceExecutionResult(success, msg)
            }

            // अज्ञात कमांड
            else -> {
                // अगर सिर्फ किसी टेक्स्ट का नाम बोला हो तो उस पर क्लिक करने की कोशिश करें
                val success = service.clickOnText(rawSpokenText)
                if (success) {
                    val msg = "$rawSpokenText पर टैप किया गया"
                    speak(msg)
                    VoiceExecutionResult(true, msg)
                } else {
                    val msg = "कमांड समझ नहीं आया। बोलिए: 'स्क्रीन पढ़ो', 'वापस जाओ', या 'खोलो [ऐप]'।"
                    speak(msg)
                    VoiceExecutionResult(false, msg)
                }
            }
        }

        onCommandCallback?.invoke(rawSpokenText, result)
    }

    // ==========================================
    // RecognitionListener इम्प्लीमेंटेशन
    // ==========================================

    override fun onResults(results: Bundle?) {
        isListening = false
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (!matches.isNullOrEmpty()) {
            val spokenText = matches[0]
            processVoiceCommand(spokenText)
        }
    }

    override fun onReadyForSpeech(params: Bundle?) {
        Log.d(TAG, "SpeechRecognizer is ready for speech")
    }

    override fun onBeginningOfSpeech() {
        Log.d(TAG, "User started speaking")
    }

    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {
        isListening = false
    }

    override fun onError(error: Int) {
        isListening = false
        val errorMsg = when (error) {
            SpeechRecognizer.ERROR_NO_MATCH -> "कोई आवाज़ पहचानी नहीं गई"
            SpeechRecognizer.ERROR_NETWORK -> "नेटवर्क समस्या"
            SpeechRecognizer.ERROR_AUDIO -> "ऑडियो रिकॉर्डिंग में त्रुटि"
            else -> "त्रुटि कोड: $error"
        }
        Log.w(TAG, "Speech recognition error: $errorMsg")
    }

    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}

    fun destroy() {
        try {
            speechRecognizer?.destroy()
            textToSpeech?.stop()
            textToSpeech?.shutdown()
        } catch (e: Exception) {
            Log.e(TAG, "Error cleaning up VoiceManager: ${e.message}")
        }
    }
}

data class VoiceExecutionResult(
    val isSuccess: Boolean,
    val message: String
)
