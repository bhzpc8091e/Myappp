package com.voiceaccess.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatusAccessibility: TextView
    private lateinit var tvStatusAudio: TextView
    private lateinit var tvStatusOverlay: TextView
    private lateinit var tvLogs: TextView
    private lateinit var btnEnableAccessibility: Button
    private lateinit var btnGrantAudio: Button
    private lateinit var btnGrantOverlay: Button
    private lateinit var btnTestVoice: Button
    private lateinit var btnReadScreen: Button

    private var voiceManager: VoiceManager? = null

    companion object {
        private const val REQUEST_RECORD_AUDIO = 200
        private const val REQUEST_OVERLAY_PERMISSION = 201
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        setupListeners()
        initVoiceManager()
    }

    private fun initViews() {
        tvStatusAccessibility = findViewById(R.id.tvStatusAccessibility)
        tvStatusAudio = findViewById(R.id.tvStatusAudio)
        tvStatusOverlay = findViewById(R.id.tvStatusOverlay)
        tvLogs = findViewById(R.id.tvLogs)

        btnEnableAccessibility = findViewById(R.id.btnEnableAccessibility)
        btnGrantAudio = findViewById(R.id.btnGrantAudio)
        btnGrantOverlay = findViewById(R.id.btnGrantOverlay)
        btnTestVoice = findViewById(R.id.btnTestVoice)
        btnReadScreen = findViewById(R.id.btnReadScreen)
    }

    private fun initVoiceManager() {
        voiceManager = VoiceManager(this) { command, result ->
            val logMessage = "
[Voice]: '$command' -> ${if (result.isSuccess) "सफल" else "विफल"}: ${result.message}"
            tvLogs.append(logMessage)
        }
    }

    private fun setupListeners() {
        // 1. एक्सेसिबिलिटी सेटिंग्स खोलें
        btnEnableAccessibility.setOnClickListener {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(intent)
            Toast.makeText(this, "सूची में 'Voice Access Assistant' खोजें और ON करें", Toast.LENGTH_LONG).show()
        }

        // 2. ऑडियो रिकॉर्ड परमिशन
        btnGrantAudio.setOnClickListener {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                REQUEST_RECORD_AUDIO
            )
        }

        // 3. डिस्प्ले ओवर ऐप्स परमिशन
        btnGrantOverlay.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!Settings.canDrawOverlays(this)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION)
                } else {
                    startFloatingService()
                }
            }
        }

        // 4. वॉयस टेस्ट
        btnTestVoice.setOnClickListener {
            voiceManager?.speak("नमस्ते! बोलिए, मैं क्या मदद कर सकता हूँ?") {
                voiceManager?.startListening()
            }
        }

        // 5. स्क्रीन पढ़ें
        btnReadScreen.setOnClickListener {
            val service = VoiceAccessibilityService.instance
            if (service != null) {
                val screen = service.readScreenContent()
                voiceManager?.speak(screen.fullSummary)
                tvLogs.append("
[Screen Reader]: ${screen.fullSummary}")
            } else {
                Toast.makeText(this, "कृपया पहले एक्सेसिबिलिटी सर्विस इनेबल करें", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
    }

    private fun updatePermissionStatus() {
        val isA11yOn = VoiceAccessibilityService.isServiceRunning
        tvStatusAccessibility.text = if (isA11yOn) "सक्रिय (ON)" else "निष्क्रिय (OFF) - कृपया चालू करें"
        tvStatusAccessibility.setTextColor(if (isA11yOn) 0xFF10B981.toInt() else 0xFFEF4444.toInt())

        val isAudioGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        tvStatusAudio.text = if (isAudioGranted) "अनुमति प्राप्त (Granted)" else "अनुमति आवश्यक"
        tvStatusAudio.setTextColor(if (isAudioGranted) 0xFF10B981.toInt() else 0xFFEF4444.toInt())

        val isOverlayGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) Settings.canDrawOverlays(this) else true
        tvStatusOverlay.text = if (isOverlayGranted) "अनुमति प्राप्त (Granted)" else "अनुमति आवश्यक"
        tvStatusOverlay.setTextColor(if (isOverlayGranted) 0xFF10B981.toInt() else 0xFFEF4444.toInt())

        if (isOverlayGranted && !isMyServiceRunning(FloatingVoiceService::class.java)) {
            startFloatingService()
        }
    }

    private fun startFloatingService() {
        val intent = Intent(this, FloatingVoiceService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun isMyServiceRunning(serviceClass: Class<*>): Boolean {
        val manager = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        for (service in manager.getRunningServices(Int.MAX_VALUE)) {
            if (serviceClass.name == service.service.className) {
                return true
            }
        }
        return false
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceManager?.destroy()
    }
}
