# Voice Access Assistant (Native Kotlin Android App)

यह एक नेटिव एंड्रॉइड ऐप है जो कोटलिन (Kotlin) में लिखी गई है। इसमें:
1. **AccessibilityService**: स्क्रीन के सभी विजिबल नोड्स को पढ़ना (Screen Reader), को-ऑर्डिनेट्स या टेक्स्ट पर टैप करना (Tap Automation), स्क्रॉल करना, और दूसरे ऐप्स खोलना।
2. **Speech Recognition**: आवाज़ से कमांड सुनना (हिंदी और अंग्रेजी दोनों में)।
3. **Text-To-Speech (TTS)**: स्क्रीन का कंटेंट और जवाब आवाज़ में बोलकर बताना।
4. **Floating Mic Overlay**: अन्य सभी ऐप्स के ऊपर फ्लोटिंग माइक बटन ताकि किसी भी ऐप में वॉयस कंट्रोल काम करे।

---

## 🛠️ APK कैसे बनाएं (How to Build APK in Android Studio)

### चरण 1: प्रोजेक्ट डाउनलोड और एक्सट्रैक्ट करें
1. वेब इंटरफ़ेस से **"Download Complete Android Studio Project (.ZIP)"** बटन दबाकर ज़िप फ़ाइल डाउनलोड करें।
2. अपने कंप्यूटर पर ज़िप फ़ाइल को अनज़िप (Extract) करें।

### चरण 2: Android Studio में खोलें
1. **Android Studio** खोलें।
2. **"Open"** पर क्लिक करें और एक्सट्रैक्ट किए गए फोल्डर को चुनें।
3. Gradle सिंक (Gradle Sync) पूरा होने दें (लगभग 1-2 मिनट)।

### चरण 3: APK फ़ाइल बनाएं (Build APK)
1. टॉप मेनू में जाएँ: **Build > Build Bundle(s) / APK(s) > Build APK(s)** पर क्लिक करें।
2. कुछ ही सेकंड में नीचे दाईं तरफ नोटिफिकेशन आएगा: *"APK(s) generated successfully"*.
3. **"locate"** पर क्लिक करें। आपकी `app-debug.apk` फ़ाइल तैयार है!

### चरण 4: अपने फ़ोन में इंस्टॉल करें
- फ़ोन को USB से कनेक्ट करके `adb install app/build/outputs/apk/debug/app-debug.apk` चलाएँ, या
- APK फ़ाइल को WhatsApp / Google Drive के माध्यम से फ़ोन में भेजकर इंस्टॉल करें।

### चरण 5: आवश्यक अनुमतियाँ चालू करें
1. फ़ोन की **Settings -> Accessibility -> Downloaded Apps** में जाएँ।
2. **"Voice Access Assistant"** पर टैप करें और **Turn ON** करें।
3. ऐप खोलकर **Microphone** और **Display over other apps** की अनुमति दें।
